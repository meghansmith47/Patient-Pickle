class BrowserDetect:
    def i_am(self):
        return 'Pyjd-mshtml'
