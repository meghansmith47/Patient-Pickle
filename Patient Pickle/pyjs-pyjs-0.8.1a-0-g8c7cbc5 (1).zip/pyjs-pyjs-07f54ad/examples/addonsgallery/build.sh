#!/bin/sh
../../bin/pyjsbuild $@ AddonsGallery
