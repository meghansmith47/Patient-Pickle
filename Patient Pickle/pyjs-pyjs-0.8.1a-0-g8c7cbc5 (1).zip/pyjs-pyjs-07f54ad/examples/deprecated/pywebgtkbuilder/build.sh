#!/bin/sh
../../../bin/pyjsbuild --library_dir=../../../pygtkweb/library $@ AutoGtk
