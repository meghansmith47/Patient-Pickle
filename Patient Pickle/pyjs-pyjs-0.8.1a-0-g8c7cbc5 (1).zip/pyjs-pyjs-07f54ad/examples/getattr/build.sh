#!/bin/sh
../../bin/pyjsbuild $@ MainTest
