#!/bin/sh
../../bin/pyjsbuild $@ AjaxTest
