#!/bin/sh
../../bin/pyjsbuild $@ KitchenSink
