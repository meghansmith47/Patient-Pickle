python ../../../builder/build.py ControlDemo.py
