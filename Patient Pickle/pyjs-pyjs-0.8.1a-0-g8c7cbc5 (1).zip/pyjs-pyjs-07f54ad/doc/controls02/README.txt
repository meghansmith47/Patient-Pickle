This is the source code directory.  Clicking on the source code file,
ControlDemo.html, does nothing.  If you're reading this off the Internet,
and you actually want the javascript to be loaded, that's in the output/
directory.  Go to output/ControlDemo.html with your browser, and you'll
find that magically, it works.

If, however, you're using Pyjamas Desktop, you're in the right place:
you want "pyjd.py ./ControlDemo.py" or "pyjd.py ./ControlDemo.html"
in THIS directory.  If you do "pyjd.py ./ControlDemo.html" in the
output/ directory, confusingly, it will also work... but that will
be because you'll be running the javascript via pygwt.js and
then Safari.cache.html, not the python file, ControlDemo.py.

You'll get used to it, soon enough :)

