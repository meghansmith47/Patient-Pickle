class BrowserDetect:
    def i_am(self):
        return 'Safari'
