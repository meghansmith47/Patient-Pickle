examplevar = 'Unaltered';
function get_examplevar( ) {
        return examplevar;
}
