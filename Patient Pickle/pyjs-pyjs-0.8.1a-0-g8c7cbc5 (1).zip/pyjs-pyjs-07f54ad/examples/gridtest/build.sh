#!/bin/sh
../../bin/pyjsbuild $@ GridTest
