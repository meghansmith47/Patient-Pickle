#!/bin/sh
../../bin/pyjsbuild $@ ControlDemo
