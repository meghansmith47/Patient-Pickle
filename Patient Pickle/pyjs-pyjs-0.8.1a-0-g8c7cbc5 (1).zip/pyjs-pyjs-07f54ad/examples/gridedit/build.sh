#!/bin/sh
../../bin/pyjsbuild $@ GridEdit
