#!/bin/sh
../../bin/pyjsbuild $@ BrowserDetect
