#!/bin/sh
../../bin/pyjsbuild $@ FormPanelExample
