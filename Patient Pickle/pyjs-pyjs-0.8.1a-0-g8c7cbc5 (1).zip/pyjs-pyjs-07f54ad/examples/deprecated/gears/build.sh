#!/bin/sh
../../../bin/pyjsbuild $@ GearsDemo
