#!/bin/sh
../../bin/pyjsbuild $@ InfoDirectory
