    test_fn = function() {
        alert("test dynamic loaded function call");
    }
    alert("load of test dynamic module");
