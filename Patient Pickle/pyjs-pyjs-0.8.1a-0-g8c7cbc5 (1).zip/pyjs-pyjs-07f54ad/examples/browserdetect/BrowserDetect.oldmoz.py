class BrowserDetect:
    def i_am(self):
        return 'Old Mozilla'
