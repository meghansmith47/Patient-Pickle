1) Type in python into the left text input box.
   e.g. def fred(): return "hello"

2) Type in the name of the module in the "Name" box.

3) hit "compile".

your python will be converted to javascript and displayed on the right.

Contributed by Jeremy <finder83@gmail.com>

