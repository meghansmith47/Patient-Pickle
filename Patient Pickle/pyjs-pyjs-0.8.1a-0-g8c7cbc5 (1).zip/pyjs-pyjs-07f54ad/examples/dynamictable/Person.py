class Person:

    def __init__(self, description = "DESC", name= ""):
        self.description = description
        self.name = name
    
    def getDescription(self):
        return self.description

    def getName(self):
        return self.name

    def getSchedule(self, daysFilter):
        pass

